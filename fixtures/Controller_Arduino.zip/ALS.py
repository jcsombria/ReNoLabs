'''
@author: jcsombria
'''
import ujson
import serial
from serial import SerialException
from serial.tools import list_ports
import threading
import re
import zmq

class Arduino():
  '''
  Arduino Adapter
  '''

  def __init__(self):
    '''
    Constructor
    '''
    self.arduino = None
    self.arduino_connected = False
    self.measurement = {}
    context = zmq.Context()
    self.socket = context.socket(zmq.REP)
    self.notify = context.socket(zmq.PUB)
    self.socket.bind("tcp://127.0.0.1:5555")
    self.notify.bind("tcp://127.0.0.1:5556")

  def connect_arduino(self):
    ports = list_ports.comports()
    self.arduino_connected = True
    for p in ports:
      try:
        print('[INFO] Connecting to %s' % p.device)
        self.arduino = serial.serial_for_url(p.device, baudrate=115200, timeout=5, write_timeout=5)
        self.arduino_thread = threading.Thread(target=self.update).start()
        break
      except:
        print('[INFO] Cannot connect to %s, trying another port' % p.device)
    if self.arduino is None or not self.arduino.is_open:
      print('[ERROR] Cannot connect to arduino, stopping server')
      self.stop()

  def parse_string(self, s):
    # Parse command string ('<name>: [1, ...]') and extract elements. 
    try:
        v = re.match('(.*):\s*\[(.*)\]', s).groups()
        name = v[0]
        values = v[1].split(',')
        id = int(values[0])
        args = [float(a) for a in values[1:]]
        return {
            'task_name': name,
            'task_id': id,
            'task_args': args,
        }
    except:
        print('[Error] Invalid format')
        return None

  def start(self):
    if not self.arduino_connected:
      self.connect_arduino()

      def loop(board):
        while board.arduino_connected:
          board.command()
      command_thread = threading.Thread(target=loop,args=(self,))
      command_thread.start()


  def stop(self):
    self.arduino_connected = False
    if self.arduino is not None:
      self.arduino.close()
      self.arduino = None
    self.measurement = {}

  def update(self):
    while self.arduino_connected:
      try:
        data = self.arduino.read_until()
        self.measurement = ujson.loads(data)
        msg = 'evolution:[%s,%s]' % (
          self.measurement['timestamp'],
          ','.join([str(v) for v in self.measurement['y']])
        )
        self.notify.send_string(msg)
      except (ValueError, TypeError) as e:
        print('[WARNING] Ignoring invalid data from Arduino')
      except SerialException as e:
        print('[WARNING] Disconnected from Arduino.')
        self.stop()
    print('[INFO] Stopping arduino thread')

  def set(self, expid, variables, values):
    '''
    Writes one or more variables to the Arduino
    '''
    toWrite = {}
    n = len(variables)
    for i in range(n):
      try:
        toWrite[variables[i]] = values[i]
      except:
        pass
    toArduino = ujson.dumps(toWrite) + "\n"
    if self.arduino_connected:
      self.arduino.write(toArduino.encode('utf-8'))

  def get(self, expid, variables):
    '''
    Retrieve one or more variables from the workspace of the current Octave session
    '''
    toReturn = {}
    n = len(variables)
    for i in range(n):
      name = variables[i]
      try:
        toReturn[name] = self.measurement[name]
      except:
        pass
    return toReturn

  def command(self):
    message = self.socket.recv_string()
    print("Received request: %s" % message)
    command = self.parse_string(message)
    try:
        name = command['task_name']
        id = command['task_id']
        args = command['task_args']
        if name == 'config':
            if id == 0:
              self.stop()
        print("Action Completed.\n")
    except:
        print('[Error] Invalid command.\n')
    self.socket.send_string(message)

if __name__ == "__main__":
  print("Arduino is listening\n")
  board = Arduino()
  board.start()